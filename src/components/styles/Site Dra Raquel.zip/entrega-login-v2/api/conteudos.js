import { sessaoValida } from './_sessao.js';
import { CONTEUDOS } from './_conteudos.js';

// Só entrega a lista de vídeos para quem fez login
export default function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (!sessaoValida(req)) return res.status(401).json({ erro: 'Faça login' });
  return res.status(200).json({ conteudos: CONTEUDOS });
}
